﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace do_an.CRUD_data.Product.createProduct
{
    public static class Consts
    {
        public const string code = "ip14";
        public const string name = "Iphone14";
        public const string amount = "10";
        public const string image = "C:\\Users\\NITRO\\Downloads\\iphone-14_1.webp";
        public const string color = "";
        public const string category = "1";
        public const string brand = "1";
        public const string priceSell = "1000";
        public const string priceBuy = "1500";
        public const string storage = "528";
    }
}
