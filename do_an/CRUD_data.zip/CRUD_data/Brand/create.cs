﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace do_an.CRUD_data.Brand.create
{
    public static class Consts
    {
        public const string name = "Oppo";
        public const string description = "Oppo";
    }
}
