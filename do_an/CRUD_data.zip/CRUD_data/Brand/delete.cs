﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace do_an.CRUD_data.Brand.delete
{
    public static class Consts
    {
        public const string name = "SamSung";
    }
}
