﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace do_an.CRUD_data.login
{
    public static class Consts
    {
        public const string email = "admin123@gmail.com";
        public const string password = "admin123";
    }
}
