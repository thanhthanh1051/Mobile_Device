﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace do_an.CRUD_data.Category.delete
{
    public static class Consts
    {
        public const string name = "IPad";
    }
}
