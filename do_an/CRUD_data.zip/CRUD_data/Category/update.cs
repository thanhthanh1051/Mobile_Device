﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace do_an.CRUD_data.Category.update
{
    public static class Consts
    {
        public const string name = "Computer";
        public const string description = "IPadd";
        public const string newName = "IPad";
    }
}
